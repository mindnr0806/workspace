package com.kh.practice.numRange.controller.NumberController;

import com.kh.practice.numRange.exception.NumRangeException.NumRangeException;

public class NumberController {

	public NumberController() {}
	
	public boolean checkDouble(int num1, int num2) throws NumRangeException {
	
	int num1 = sc.nextInt();
	int num2 = sc.nextInt();
		
		if(num1)
	}

	public int checkDouble(String str) {
		// TODO Auto-generated method stub
		return 0;
	}

}
