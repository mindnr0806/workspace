package com.kh.practice.numRange.exception.NumRangeException;

public class NumRangeException extends Exception{
	
	public NumRangeException() {}
	
	public NumRangeException(String msg) {}
	
}
